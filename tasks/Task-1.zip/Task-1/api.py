from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/books', methods=['GET'])
def get_books():
    books = [
        {"id": 1, "title": "The Art of Ethical Hacking"}, 
        {"id": 2, "title": "Malware for dummies"},
        {"id": 3, "title": "Rust for Malware Development"},
        {"id": 4, "title": "End Point Detection and evasion"}
    ]
    return jsonify(books)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
from flask import Flask, jsonify

app = Flask(__name__)

@app.route('/books', methods=['GET'])
def get_books():
    books = [{"id": 1, "title": "Book A"}, {"id": 2, "title": "Book B"}]
    return jsonify(books)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

