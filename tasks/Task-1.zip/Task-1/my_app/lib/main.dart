import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:permission_handler/permission_handler.dart';
import 'package:installed_apps/installed_apps.dart';
import 'package:installed_apps/app_info.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List books = [];
  List<String> installedApps = [];
  bool isLoadingBooks = false;
  bool isLoadingApps = false;

  // 📌 Fetch books from API
  Future<void> fetchBooks() async {
    setState(() {
      isLoadingBooks = true;
    });

    try {
      var response = await http.get(Uri.parse('https://80f4-2405-201-e048-905f-9d08-57d7-c216-4f1c.ngrok-free.app/books'));

      if (response.statusCode == 200) {
        setState(() {
          books = json.decode(response.body);
        });
      } else {
        print("Error: ${response.statusCode} - ${response.body}");
      }
    } catch (e) {
      print("Error fetching books: $e");
    } finally {
      setState(() {
        isLoadingBooks = false;
      });
    }
  }

  // 📌 Request camera/microphone permission
  Future<void> requestPermission(Permission permission) async {
    await permission.request();
  }

  // 📌 Get installed apps
  Future<void> getInstalledApps() async {
    setState(() {
      isLoadingApps = true;
    });

    try {
      List<AppInfo> apps = await InstalledApps.getInstalledApps();
      setState(() {
        installedApps = apps.map((app) => app.name).toList();
      });
    } catch (e) {
      print("Error fetching installed apps: $e");
    } finally {
      setState(() {
        isLoadingApps = false;
      });
    }
  }

  @override
  void initState() {
    super.initState();
    fetchBooks();
    getInstalledApps();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("My App"),
        centerTitle: true,
        actions: [
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: fetchBooks,
          )
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // 📷 Camera & Mic Permission Buttons
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton.icon(
                  onPressed: () => requestPermission(Permission.camera),
                  icon: Icon(Icons.camera_alt),
                  label: Text("Camera"),
                ),
                ElevatedButton.icon(
                  onPressed: () => requestPermission(Permission.microphone),
                  icon: Icon(Icons.mic),
                  label: Text("Mic"),
                ),
              ],
            ),

            SizedBox(height: 10),

            // 📚 Book List Section
            Expanded(
              child: Column(
                children: [
                  Text(
                    "Books",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Divider(),
                  Expanded(
                    child: isLoadingBooks
                        ? Center(child: CircularProgressIndicator())
                        : books.isEmpty
                            ? Center(child: Text("No books found"))
                            : ListView.builder(
                                itemCount: books.length,
                                itemBuilder: (context, index) {
                                  return ListTile(
                                    leading: Icon(Icons.book, color: Colors.blue),
                                    title: Text(books[index]['title']),
                                  );
                                },
                              ),
                  ),
                ],
              ),
            ),

            SizedBox(height: 10),

            // 📱 Installed Apps Section
            Expanded(
              child: Column(
                children: [
                  Text(
                    "Installed Apps",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  Divider(),
                  Expanded(
                    child: isLoadingApps
                        ? Center(child: CircularProgressIndicator())
                        : installedApps.isEmpty
                            ? Center(child: Text("No apps found"))
                            : ListView.builder(
                                itemCount: installedApps.length,
                                itemBuilder: (context, index) {
                                  return ListTile(
                                    leading: Icon(Icons.apps, color: Colors.green),
                                    title: Text(installedApps[index]),
                                  );
                                },
                              ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
